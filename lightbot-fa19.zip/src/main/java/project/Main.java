/**
 * 
 */
package project;

/**
 * @author TSXN4236
 *
 */
public class Main {

    /**
     * @param args
     */
    public static void main(String[] args) {
	// TODO Auto-generated method stub
	System.out.println("toto");

    }

}
