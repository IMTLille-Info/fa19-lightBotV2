/**
 * 
 */
package project;

/**
 * @author TSXN4236
 *
 */
import org.newdawn.slick.SlickException;
import org.newdawn.slick.tiled.TiledMap;


public class Maps {

}
