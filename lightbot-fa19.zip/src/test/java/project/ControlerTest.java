/**
 * 
 */
package project;

import static org.junit.Assert.*;

import org.junit.Test;

import junit.framework.*;

/**
 * @author TSXN4236
 *
 */
public class ControlerTest {
    

    private static final Object val = "1";

    @Test
    public void test() {
	assertEquals("1", val);
	//fail("Not yet implemented");
    }

}
