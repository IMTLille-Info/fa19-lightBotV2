/**
 * 
 */
package project;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author TSXN4236
 *
 */
public class WindowsGameTest {

    @Test
    public void test() {
	fail("Not yet implemented");
    }

}
